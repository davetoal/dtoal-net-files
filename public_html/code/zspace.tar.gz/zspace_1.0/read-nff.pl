
# this fn reads in an nff file
# passed in as $1
# and returns a reference to 
# a hash with numpts, numlns defined
# px1 py1 pz1
# numl1 l11 l12 l13 ..l1n
#


sub read_nff {

  my ($fname) = @_;

  print "starting nff read, opening $fname\n";

  my $r;

  my %o;

  my ($a, $b, $c, 
      $f, $i, $j, 
      $x, $y, $p, $l,
      $pa, $pb, $pc,
      $rx, $ry, $rz,
      $e, $v, $rl, $rp   );

  my ($line, @info);


  open(O, "< $fname") or die "no file $fname? $!";

  $a = <O>; print "$a";
  $f = <O>; chomp($f);


  # read in lines

  $i = <O>; chomp($i);
  print "$i points in $f\n";

  $o{'numpts'} = $i;

  for ($p = 0; $p < $i; $p++) {

    $line = <O>;
    chomp($line);

    # print "point $p, got $line\n";

    ($a, $b, $c) = split(/ /, $line);

    $pa = $a * 1; $pb = $b * 1; $pc = $c * 1;

    # numpts, numlns, px1 py1 pz1, numl1, l11 l12 l13 .. l1n

    $rx="px$p"; $ry="py$p"; $rz="pz$p";

    # print "  $rx $pa, $ry $pb, $rz $pc\n";

    $o{$rx} = $pa;
    $o{$ry} = $pb;
    $o{$rz} = $pc;

  }


  # read in lines

  $j = <O>; chomp($j);
  print "$j lines in $f\n";

  $o{'numlns'} = $j;

  for ($l = 0; $l < $j; $l++) {

    $line = <O>;
    chomp($line);

    # print "line $l, got $line\n";

    @info = split(/ /, $line);

    $rl = "numl$l";

    # print "  $rl is $info[0]\n";

    $o{$rl} = $info[0];

    # numpts, numlns, px1 py1 pz1, numl1, l_1_1 l_1_2 l_1_3 .. l_1_n

    for ($e = 0; $e < $info[0]; $e++) {

      $v = $e + 1;

      $rp = "l_${l}_$e";

      # print "  $e, $rp is $info[$v]\n";

      $o{$rp} = $info[$v];

    }

  }

  close(O);

  $r = \%o;
  return($r);

}


1;

