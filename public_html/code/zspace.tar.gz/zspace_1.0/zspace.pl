#!/usr/bin/perl
# dave toal 256 2k4
# any frame of reference is arbitrarily defined
# window onto pixel space, 
# nav and rot buttons
#
#           [up]  [forward]
# [left]   [home]   [right]
#  [back]  [down]
#
# [z ccw]  [x ccw] 
# [y ccw]           [y cw]
#          [x cw]   [z cw]
#
# row along bottom of screen 
# for nav step increments, map screen from start
# depending on screen rate, buttons for engines, gravity
# callbacks on redraw()
#
# clipping is simple if the viewpoint is the camera onto the world
# do all moves to objects, camera is fixed at 0, looking along z
# eye is at negative z, distance from screen and size of viewport
# determines the angle of the clipping frustrum.  z > 0, xy < ratio at z
# set frustrum smaller than viewport, sweep through objects
# move the world, sweep objects through the frustrum
#

# the bug in the viewport that stops pixels whose z distance is < 0
# from being drawn on the page, is happening because z is being clipped
# in zspace coords relative to the crux position, z=0
# instead of in viewport coords, cx cy z0.
# the difference is the order of rotate, move, draw
# move, rotate for zspace, rotate, move for viewport
# demo of acid bath effect, polys being clipped at zspace z=0
# by moving to xrot -61, yrot 0, zrot 180
# xpos 0 inches, ypos 7.1 inches, zpos 0.3 inches
# mult these back by $zf to check position
# set move to 0.1 inches and hit F and B, watch as polys disappear
# when crossing zspace 0.
# their zspace 0, not viewport display frustrum zspace, cx cy z0
# clip polys to draw after applying viewport matrix transforms,
# not before.  duh.  clip x y by ratio of z, edges of view cone, iz to cx cy
# check speed, might be fine to draw all z>0 each time.
#
# redraw at x 0 y 600 z 30  xr -61 yr 0 zr 180
#
# to fix this, rotate and draw to viewport have to be split up
# into separate steps.  pass back ref to 3pt, call move by passing ref to 3pt
# rotate is called by 3pt already.
# do fns for 3pt + xyz add
# and 3pt * xyz rotate
# which is what current draw would do
# if it handed back results before adding to xyz
#
# do these as external functions like amult
# time diff for passing 3pts and refs, vs objs.
#
# compare all this to doing lines and &c from the nffs
# in opengl.  capture button events, iopjjlnm,qweasdzxc
# generate nff for httpd event log,
# lines, 3d surfaces, for each ip that touches the httpd
# some kind of tree thing of what dirs hit, time is the x axis
# group hits by same ip, label, draw lines to same one from the side
# at different rotations around the x axis, at different r for each ip
# ones that hit more often, bigger r, further from the x axis
# 

use strict;
use Tk;

require "matrix.pl";
# amult, array x point multiply fn

require "read-nff.pl";
# read_nff fn, returns ref to hash
# numpts, numlns, px1 py1 pz1, numl1, l11 l12 l13 .. l1n
# all lines are edges of closed polys

# require "rotate-and-draw.pl";
# map xyz to xy of viewport


my $xpos = 0;
my $ypos = 0;
my $zpos = 0;
 
my $xrot = 0;
my $yrot = 0;
my $zrot = 0;
 
my $step = 10; 
my $rotstep = 10; 

my $conv = (2 * 3.1415926) / 360;

my $scf = 1;
# global object scale factor

my $ref;
my ($ref2, $f2);
# reference to object hash


my $top1 = MainWindow->new();
$top1->title("nav and map");

my $top2 = MainWindow->new();
$top2->title("viewport");

# $top1->overrideredirect(1);

my $width = 1000;
my $height = 700;
# is 12 inches by 8 and 1/4

my $canv = $top2->Canvas( width => $width, height => $height,
                          relief => 'groove', borderwidth => 4,
                          bg => '#c4c0a4' );
$canv->pack();                        


my $xf = $width / 12.0;
my $yf = $height / 8.25;
my $zf = ( $xf + $yf ) / 2;
# pixels/inch

my $ix = 0;
my $iy = 0;
my $iz = 28.0 * $zf;
# eye x,y,z for viewpoint plane.
# objects are clipped to z >= 0 and ratio of z 
#   by xy of /.\ view frustrum
# iz is the height of the eye view triangle at cx cy on the screen.  
# ratio of iz to iz + z gives dx dy from px py.  same method for 
# clipping frustrum, ratio of dx dy at z depth.


my $cx = $width / 2;
my $cy = $height / 2;
# viewport cx cy

# canvas for nav toolpage map
my $cw = 293;
my $ch = 160;
my $bw = 5;

my $toolpage = $top1->Canvas( -height => $ch , -width => $cw, -relief => "ridge",
                              -borderwidth => $bw ) -> pack( -side => "top", -anchor => "n",
                                                             -padx => 10, -pady => 10 );

# under the navmap, a frame for button sets
# my $buttonframeheight = 116;
my $buttonframeheight = 142;

# my $buttonframeheight = 182;
# add scale for log steps on move
# instead of buttons for steps

# plus space for move/rotate display
# and range of buttons, blend, whip, puree
# read in nff at current location???
# read in, anyway, and add to displayed objects list
# then add inputs from xyz input joystick,
# map to keys or whatever, use for 3d editor
# find out how to repeat keys also
# or map udlr to qweasdzxc and bnmhjkuio
# has to be fluid for an editor

my $fbw = 2;
my $frame1 = $top1->Frame( -width => $cw, -height => $buttonframeheight,
                           -relief => "sunken", -background => "grey",
                           -borderwidth => $fbw ) -> pack( -side => "bottom", -anchor => "s",
                                                           -padx => 10, -pady => 10 );
#           [up]  [forward]
# [left]   [home]   [right]
#  [back]  [down]   

my $by1 = 10;
my $by2 = 41;
my $by3 = 72;
my $by4 = 103;
my $by5 = 134;

$frame1->Button( -text => "U", -command => \&moveup ) -> place ( -x => 48, -y => $by1 ); 
$frame1->Button( -text => "B", -command => \&moveback ) -> place ( -x => 86, -y => $by1 );  
$frame1->Button( -text => "L", -command => \&moveleft ) -> place ( -x => 12, -y => $by2 );  
$frame1->Button( -text => "H", -command => \&movehome ) -> place ( -x => 48, -y => $by2 );  
$frame1->Button( -text => "R", -command => \&moveright ) -> place ( -x => 86, -y => $by2 );  
$frame1->Button( -text => "F", -command => \&movefwd ) -> place ( -x => 11, -y => $by3 );  
$frame1->Button( -text => "D", -command => \&movedown ) -> place ( -x => 48, -y => $by3 );  

$frame1->Button( -text => ".", -command => \&moveacidbath ) -> place ( -x => 122, -y => $by1 );  

sub moveup { print "move up\n"; $ypos += $step; redraw(); }
sub movedown { print "move down\n"; $ypos -= $step; redraw(); } 
sub moveleft { print "move left\n"; $xpos -= $step; redraw(); } 
sub moveright { print "move right\n"; $xpos += $step; redraw(); } 
sub moveback { print "move z neg, forward\n"; $zpos += $step; redraw(); } 
sub movefwd { print "move z pos, back\n"; $zpos -= $step; redraw(); } 
sub movehome { print "move home\n"; $xpos = 0; $ypos = 0; $zpos = 0; redraw(); } 
# cos view posn is like, my posn.  I move me back to see the view move forward
# I move me left to see the view move right
# or maybe y is fucked, because the screen inversion thing
# so xpos?  dx + cx

# redraw at x 0 y 600 z 30  xr -61 yr 0 zr 180
sub moveacidbath { 
  print "move to acidbath demo position\n"; 
  $xpos = 0; $ypos = 600; $zpos = 30; 
  $xrot = -61; $yrot = 0; $zrot = 180;
  redraw(); 
} 



# [z ccw]  [x ccw]
# [y ccw]           [y cw]
#          [x cw]   [z cw]  


$frame1->Button( -text => "Z-", -command => \&decz ) -> place ( -x => 153, -y => $by1 );
$frame1->Button( -text => "X-", -command => \&decx ) -> place ( -x => 194, -y => $by1 );
$frame1->Button( -text => "Y-", -command => \&decy ) -> place ( -x => 151, -y => $by2 );
$frame1->Button( -text => "rH", -command => \&xyzhome ) -> place ( -x => 194, -y => $by2 );
$frame1->Button( -text => "Y+", -command => \&incy ) -> place ( -x => 238, -y => $by2 );
$frame1->Button( -text => "X+", -command => \&incx ) -> place ( -x => 194, -y => $by3 );
$frame1->Button( -text => "Z+", -command => \&incz ) -> place ( -x => 238, -y => $by3 ); 


sub decz { print "rotate z-\n"; $zrot -= $rotstep; redraw(); }
sub decy { print "rotate y-\n"; $yrot -= $rotstep; redraw(); }
sub decx { print "rotate x-\n"; $xrot -= $rotstep; redraw(); }
sub incz { print "rotate z+\n"; $zrot += $rotstep; redraw(); }
sub incy { print "rotate y+\n"; $yrot += $rotstep; redraw(); }
sub incx { print "rotate x+\n"; $xrot += $rotstep; redraw(); }
sub xyzhome { print "xyz home\n"; $xrot = 0; $yrot = 0; $zrot = 0; redraw(); }

$frame1->Button( -text => "exit", -command => \&exitfn ) -> place ( -x => 10, -y => $by4 );
sub exitfn { print "\nexit called, bye\n\n"; exit 0; }


my $mvs;

$mvs = $frame1->Scale( -from => 1, -to => 16, -orient => 'horizontal',
                       -showvalue => 0, -background => "grey", -length => 204,
                       -command => \&updatestep, -troughcolor => "grey" )
              -> place ( -x => 66, -y => $by4 + 2 );



sub getunits {

  my ($size) = @_;

  my ($unit, $measure, $ms, $sz);

  $sz = abs($size);

  $measure = $size, $unit = "inches" if ($sz < 13);
  $measure = $size / 12, $unit = "feet" if (($sz > 13) and ($sz < 37));
  $measure = $size / 36, $unit = "yards" if (($sz > 37) and ($sz < 63360));
  $measure = $size / 63360, $unit = "miles" if (($sz > 63360) and ($sz < 502217337.60));
  $measure = $size / 502217337.60, $unit = "earths" if (($sz > 502217337.60) and ($sz < 5892480000000));
  $measure = $size / 5892480000000, $unit = "a.u." if ($sz > 5892480000000);

  $ms = (int($measure * 10) / 10);

  return($ms, $unit);

  # ($ms, $unit) = getunits($size);

}


 
sub updatestep { 

  my $sval = $mvs->get(); 
  my $p = 1;
  my ($i, $j, @text, $js, $size, $measure, $unit, $ms,
      $ax, $ay, $az, $bx, $by, $bz, 
      $ax, $ay, $bx, $by );

  $j = $sval * 1;

  for ($i = 0; $i < $j; $i++) {
    $p = $p * 10;
  }
  # 10 ^ $sval?

  $step = $p;
  $size = (int(($p / $zf) * 10) / 10);

  ($ms, $unit) = getunits($size);

  print "scale value is $sval, $ms $unit, p is $p, j is $j\n"; 

  $toolpage->delete("movestep");
  $toolpage->createText(200, 130, -text => "scale $sval, move $p pixels", -tags => "movestep" );
  $toolpage->createText(200, 150, -text => "$ms $unit", -tags => "movestep" );


  # draw crux of rotation on toolpage, 
  # which means add another draw fn, which only rotates
  # and doesn't move first.  split up move of globals?
  # or no, do the rotate anyway, because you need it for
  # rotating individual objects.  separate move fn also
  # update coordinates of each object reference
  # add object hash to objects list
  # global callback to move world
  # individual object callbacks, to move rot objects in the world
  # the + thing on the viewport is the center of the object zspace x0 y0 z0
  # for the object that's being shown.  the fb &c buttons move the object
  # fwd, back, &c, within that zspace.  the rotate buttons rotate the view
  # of the zspace from the viewport.  the viewport looks toward a different
  # rotation of the zspace, in other words.  push the b button, and the
  # zspace of the object is pushed back along the z axis, zpos++. 
  # then the draw fn maps that xyz relative to its own cx0 cy0 cz0
  # with dx dy triangles for dz.  polys have to be clipped after that
  # set of transforms, for viewport coords z > 0.
  # instead of clipping the rotated and moved points in zspace
  # after doing the move & rotate on that set of points.
  # so this is a demo of clipping against a plane in 3space
  # built sideways.
  # up and down are rotated in the acidbath demo position
  # because zrot is 180, the world is turned upside down and
  # the viewport is looking at the underside of it.  moving 
  # the world up, makes the object in the view from the viewport
  # move down.  the crux  + thing is the center of object space



  $js = 100;

  # vert
  $ax = 0; $bx = 0;
  $ay = $js; $by = -$js;
  $az = 0; $bz = 0;

  # horiz
  $ax = -$js; $bx = $js;
  $ay = 0; $by = 0;
  $az = 0; $bz = 0;

  # along
  $ax = 0; $bx = 0;
  $ay = 0; $by = 0;
  $az = -$js; $bz = $js;

  # now draw these rotated only, not moved
  # from xyz on toolpage

  # have to call draw fns, dl is pointed at the canvas
}




$frame1->Button( -text => "1", -command => \&rotstep1 ) -> place ( -x => 86, -y => $by3 );
sub rotstep1 { print "rotstep set to 1\n"; $rotstep = 1; }

$frame1->Button( -text => "0", -command => \&rotstep10 ) -> place ( -x => 122, -y => $by3 );
sub rotstep10 { print "rotstep set to 10\n"; $rotstep = 10; }

$frame1->Button( -text => "9", -command => \&rotstep90 ) -> place ( -x => 158, -y => $by3 );
sub rotstep90 { print "rotstep set to 90\n"; $rotstep = 90; }




my $groundplane = 1;

$frame1->Button( -text => "+", -command => \&toggleground ) -> place ( -x => 12, -y => $by1 );
sub toggleground { 
  if ($groundplane) { 
    $groundplane = 0; 
    print "ground off\n";
    redraw();
  } else { 
    $groundplane = 1;
    print "ground on\n";
    redraw();
  }
}



my $globalmove = 0;

$frame1->Button( -text => "g", -command => \&togglegmove ) -> place ( -x => 236, -y => $by1 );
sub togglegmove {
  if ($globalmove) {
    $globalmove = 0;
    print "global movement off\n";
    redraw();
  } else {
    $globalmove = 1;
    print "global movement on\n";
    redraw();
  }
}

# callback to sub that exits if 0, adds last vector and redraws if 1


sub rotatept {

  my ($x, $y, $z, $xrot, $yrot, $zrot) = @_;
  # this one returns point rotated to xyzrot

  my ($nx, $ny, $nz);

}



# just pass the globals from the parent, duh

sub rotateglobalpt {

  # my ($x, $y, $z, $xrot, $yrot, $zrot) = @_;
  my ($x, $y, $z) = @_;
  # rotate to global xyzrot
  
  my ($nx, $ny, $nz);
  # return rotated point

  my ($cxrot, $cyrot, $czrot);
  # xrot &c are global
  # check difference in speed vs
  # referencing the global
  # vs passing in 3pt
  # for now, reference the global,
  # because the current one does.

  my ($sinxrot, $sinyrot, $sinzrot,
      $cosxrot, $cosyrot, $coszrot);
  # elements for rotation arrays

  my (@xrot, @yrot, @zrot); 
  # rotation arrays

  my ($ref, $a, $b, $c);
  # reference to rotation array
  # 3pt for xyz passed to amult
  # (nxyz) = (amult($r, $xyz)); ?

  $cxrot = $xrot * $conv; $cyrot = $yrot * $conv; $czrot = $zrot * $conv;

  $sinxrot = sin($cxrot); $sinyrot = sin($cyrot); $sinzrot = sin($czrot);
  $cosxrot = cos($cxrot); $cosyrot = cos($cyrot); $coszrot = cos($czrot);

  @xrot = ( [ 1,         0,        0 ],
            [ 0,  $cosxrot, $sinxrot ],
            [ 0, -$sinxrot, $cosxrot ] );

  @yrot = ( [ $cosyrot, 0, -$sinyrot ],
            [ 0,        1,         0 ],
            [ $sinyrot, 0,  $cosyrot ] );

  @zrot = ( [  $coszrot, $sinzrot, 0 ],
            [ -$sinzrot, $coszrot, 0 ],
            [ 0,         0,        1 ] );

  $ref = \@xrot;
  ($a, $b, $c) = amult($ref, $x, $y, $z);
  ($x, $y, $z) = ($a, $b, $c);

  $ref = \@yrot;
  ($a, $b, $c) = amult($ref, $x, $y, $z);
  ($x, $y, $z) = ($a, $b, $c);

  $ref = \@zrot;
  # ($a, $b, $c) = amult($ref, $x, $y, $z);
  # # ($x, $y, $z) = ($a, $b, $c);
  # # ($nx, $ny, $nz) = ($a, $b, $c);
  # then did this instead, last rotated 3pt is returned
  # ($a, $b, $c) = amult($ref, $x, $y, $z);

  ($nx, $ny, $nz) = amult($ref, $x, $y, $z);

  return ($nx, $ny, $nz);

}



sub drawpt {

  my ($x, $y, $z) = @_;

  my ($px, $py);

  # iz, cx, cy, global
  my ($longz, $dx, $dy);

  # map rotated point to flat view plane
  # return x,y on the viewport, for x,y,z in pixelspace

  $longz = $z + $iz;

  # so iz is a positive number, even though
  # the eyes are on the other side of the viewport plane
  # this is why it draws negative z inverted

  $dx = ( $iz * $x ) / $longz;
  $dy = ( $iz * $y ) / $longz;

  $px = $dx + $cx;
  $py = $cy - $dy;  # for z positive, screen coords are inverted

  return($px, $py);
  # return x y on viewport cx0 cy0

}



sub movept {

  my ($x, $y, $z, $dx, $dy, $dz) = @_;
  # takes 3pt xyz and returns x + dx &c

  my ($nx, $ny, $nz);

  $nx = $x + $dx; $ny = $y + $dy; $nz = $z + $dz;

  return ($nx, $ny, $nz);

}



sub dl {

  my ($ix, $iy, $iz, $jx, $jy, $jz) = @_;

  my ($mix, $miy, $miz,
      $mjx, $mjy, $mjz,
      $rmix, $rmiy, $rmiz,
      $rmjx, $rmjy, $rmjz,
      $pix, $piy, 
      $pjx, $pjy );

  # z = 0 is the glass

  ($mix, $miy, $miz) = movept($ix, $iy, $iz, $xpos, $ypos, $zpos);
  ($mjx, $mjy, $mjz) = movept($jx, $jy, $jz, $xpos, $ypos, $zpos);

  ($rmix, $rmiy, $rmiz) = rotateglobalpt($mix, $miy, $miz);
  ($rmjx, $rmjy, $rmjz) = rotateglobalpt($mjx, $mjy, $mjz);

  if ( ($rmiz > 0) and ($rmjz > 0) ) {

    ($pix, $piy) = drawpt($rmix, $rmiy, $rmiz);
    ($pjx, $pjy) = drawpt($rmjx, $rmjy, $rmjz);

    $canv->create('line', $pix, $piy, $pjx, $pjy, -tags => "lines");
  }

}



sub draw_object {

  my ($ref) = @_;

  my ($numpts, $numlns,
      $px, $py, $pz,
      $rax, $ray, $raz,
      $rbx, $rby, $rbz,
      $ax, $ay, $az,
      $bx, $by, $bz,
      $count, $l, $p, $q, @v,
      $pref, $countref,
      $aox, $aoy, $box, $boy,
      $p1, $p2   );

  $numpts = $$ref{'numpts'};
  $numlns = $$ref{'numlns'};

  print "redraw, object has $numpts points, $numlns lines\n";

  # for l in lines
  # get index of point number for each vertex
  # draw with 0,1 1,2 2,3 3,0 calls to draw()

  for ($l = 0; $l < $numlns; $l++) {

    # $rl = "numl$l";
    $countref = "numl$l";
    $count = $$ref{$countref};

    # print "number of points in poly $l is $countref, $count\n";

    for ($p = 0; $p < $count; $p++) {

      # $rp = "l_${l}_$e";
      $pref = "l_${l}_$p";
      $v[$p] = $$ref{$pref};
      # print "p ref is $pref, point is number $v[$p]\n";

    }

    # points are assigned, now draw each poly
    # for r 0, < 3
    # s = r + 1
    # axyz = ref(ref(r)); bxyz = ref(ref(s));
    # then do last to 0, outside loop

    for ($p1 = 0; $p1 < ($count - 1); $p1++) {

      $p2 = $p1 + 1 ;
      # print "p1 p2, drawing from $p1 to $p2, ";

      $rax="px$v[$p1]"; $ray="py$v[$p1]"; $raz="pz$v[$p1]";
      $rbx="px$v[$p2]"; $rby="py$v[$p2]"; $rbz="pz$v[$p2]";

      $ax = $$ref{$rax}; $ay = $$ref{$ray}; $az = $$ref{$raz};
      $bx = $$ref{$rbx}; $by = $$ref{$rby}; $bz = $$ref{$rbz};

      $ax = $ax * $scf; $ay = $ay * $scf; $az = $az * $scf;
      $bx = $bx * $scf; $by = $by * $scf; $bz = $bz * $scf;

      dl($ax, $ay, $az, $bx, $by, $bz);

    }

    $p2 = 0;
    # print "after loop, p1 is $p1, p2 is $p2, ";

    $rax="px$v[$p1]"; $ray="py$v[$p1]"; $raz="pz$v[$p1]";
    $rbx="px$v[$p2]"; $rby="py$v[$p2]"; $rbz="pz$v[$p2]";

    $ax = $$ref{$rax}; $ay = $$ref{$ray}; $az = $$ref{$raz};
    $bx = $$ref{$rbx}; $by = $$ref{$rby}; $bz = $$ref{$rbz};

    $ax = $ax * $scf; $ay = $ay * $scf; $az = $az * $scf;
    $bx = $bx * $scf; $by = $by * $scf; $bz = $bz * $scf;

    dl($ax, $ay, $az, $bx, $by, $bz);

  }

}



sub move_object {

  # move_object($ref, $distance);

  my ($ref, %dis) = @_;

  my ($x, $y, $z);

  ($x, $y, $z) = ($dis{"x"}, $dis{"y"}, $dis{"z"});

  print "move object $x, $y, $z\n";

  # for each point in object %nff, 
  # add %dis to it.  no return value,
  # points of the referenced hash are changed

}

# do another one, which returns new $ref to copy of object
# moved by %distance




sub rotate_object {

  # rotate_object($ref, $xyzrot);

  my ($ref, %xyz) = @_;

  my ($x, $y, $z);

  ($x, $y, $z) = ($xyz{"x"}, $xyz{"y"}, $xyz{"z"});

  print "rotate object $x, $y, $z\n";

}



sub redraw {

  print "redraw world at x $xpos y $ypos z $zpos  xr $xrot yr $yrot zr $zrot\n";

  my ($rox, $roy, $tox, $toy,
      $rpx, $rpy, $rpz,
      $tpx, $tpy, $tpz, 
      $ix, $iy, $iz,
      $jx, $jy, $jz,
      $g1x, $g1y, $g2x, $g2y,
      $scale, $scalestep,
      $gi, $gp, $gpr, $gix, $giy, $giz,
      $xms, $yms, $zms, 
      $xunit, $yunit, $zunit,
      %dis2, %xyzrot2  );


  $canv->delete("lines");

  # ringworld surface, center of the ring is at y + .93 au
  # width of the ring is 10 k miles in pixels
  # prove pixel size by drawing a square 
  #   in inches at the screen surface, z=0
  # generate things, font of tool paths for carver

  if ($groundplane) {

    # draw crux grid at powers of ten scales

    $gpr = 1;

    for ($gi = 1; $gi < 17; $gi++) {

      $gpr *= 10;

      if ($gpr <= $step) {

        $gp = $gpr / 2;

        # squares in xy plane
        dl(-$gp, -$gp, 0, -$gp, $gp, 0);
        dl(-$gp, $gp, 0,   $gp, $gp, 0);
        dl($gp, $gp, 0,    $gp, -$gp, 0);
        dl($gp, -$gp, 0,  -$gp, -$gp, 0);

        # xz plane
        dl(-$gp, 0, -$gp, -$gp, 0, $gp);
        dl(-$gp, 0, $gp,   $gp, 0, $gp);
        dl($gp, 0, $gp,    $gp, 0, -$gp);
        dl($gp, 0, -$gp,  -$gp, 0, -$gp);

        # yz plane
        dl(0, -$gp, -$gp, 0, -$gp, $gp);
        dl(0, -$gp, $gp,  0, $gp, $gp);
        dl(0, $gp, $gp,   0, $gp, -$gp);
        dl(0, $gp, -$gp,  0, -$gp, -$gp);

      }

    }


    # parallel lines, base plane
    # $iy = 0; $jy = 0;
    # $scale     = 10000000;
    # $scalestep = 1000000;
    # $iz = 0; $jz = 502217337.60 * $zf;
    # 1 earth diameter, in pixels
    # z positive
    # for ($ix = -$scale; $ix <= $scale; $ix += $scalestep) {
    #   $jx = $ix;
    #   dl($ix, $iy, $iz, $jx, $jy, $jz);
    # }

    # draw another, grid of objects through pixelspace
  }

  # scan through points lines in each object
  # pass points to draw to get each rot,mov'd point
  # this is moving and rotating the points in each object
  # relative to the viewer.  so everything's reversed,
  # move it +10, not me +10

  # from here to end of draw p2 to p0
  # as a separate fn
  # pass ref of hash
  # can I pass ref of hash
  # as $1 on the unix pipe?  bet not,
  # it's a hash into the symbol table
  # of the current instance
  # 
  # common image, many nodes
  #
  # a node of retra shared info between itselves
  # updating changes on local events.  all bandwidth
  # over 2 ports. 
  #

  # for each object ref

  # move_object($ref, $distance);
  # rotate_object($ref, $xyzrot);
  # refs to 3pts, hashes containing values for qw(x y z)
  # types of hashes, defined by specific text keys
  # of keys contained, and interpretation of values

  draw_object($ref);

  draw_object($ref2);

  $dis2{"x"} = -300;
  $dis2{"y"} = -200;
  $dis2{"z"} = 800;

  # move_object($ref2, %dis2);

  # update toolpage rot and xyz info

  $toolpage->delete("rotinfo");
  $toolpage->createText(70, 20, -text => "xrot $xrot, yrot $yrot, zrot $zrot", -tags => "rotinfo" );

  ($xms, $xunit) = getunits(($xpos / $zf));
  ($yms, $yunit) = getunits(($ypos / $zf));
  ($zms, $zunit) = getunits(($zpos / $zf));

  $toolpage->createText(70, 40, -text => "xpos $xms $xunit", -tags => "rotinfo" );
  $toolpage->createText(70, 60, -text => "ypos $yms $yunit", -tags => "rotinfo" );
  $toolpage->createText(70, 80, -text => "zpos $zms $zunit", -tags => "rotinfo" );

  # left is black, right is white
  # up is green, down is brown
  # away is red, toward is blue
  # rotate lines from a center on toolpage
  # at rH would look like green up, brown down,
  # black left, white right, blue dot in center

  # 
}


# load in objects

# my $f1 = "./nff/cubostel.nff";
# $scf = 1000000;
# my $f1 = "./teapot.nff";
# my $f1 = "./shuttle.nff";
# $scf = 10;
# my $f1 = "./meguro.nff";
# my $f1 = "./benfish.nff";  # check nff syntax?
# my $f1 = "./tardis.nff";
# my $f1 = "./ringworld.nff";
# my $f1 = "./ringworld-zspace.nff";
# z positive

my $f1 = "./trontank.nff";
$ref = read_nff($f1);

# do array of refs, read in multiple objects
# call rotate on each one, do another fn that
# rotates the point info from the ref handle
# draw object n at xyzrot, each frame
# callbacks to move individual objects

$f2 = "./ringworld-zspace.nff";
$ref2 = read_nff($f2);



redraw();


MainLoop(); 


