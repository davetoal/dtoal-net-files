
# these fns multiply matrices
# |Tr| |point|  3x3 3x1
# refs passed in, ref to answer passed out
# or does it make more sense 
# to pass in a list of 3 values
# and pass back another list?
# @point or $x, $y, $z
# 


# pass in ref to 3x3 and 3 vals in point
# return 3 new vals multiplied by 3x3

sub amult {

  # print "starting amult\n";

  my ($r, $x, $y, $z) = @_;
  my $dim = 4;

  my ($a, $b, $c, $i, $j);

  # for ($i = 0; $i < $dim; $i++) {
  #  for ($j = 0; $j < $dim; $j++) {
  #    print "$$r[$i][$j] ";
  #   }
  #   print "\n";
  # }
  # print "point is $x, $y, $z\n";

  # first return val is first row 
  # second return val is second row

  $a = $$r[0][0] * $x  +  $$r[0][1] * $y  +  $$r[0][2] * $z;
  $b = $$r[1][0] * $x  +  $$r[1][1] * $y  +  $$r[1][2] * $z;
  $c = $$r[2][0] * $x  +  $$r[2][1] * $y  +  $$r[2][2] * $z;

  # can't cancel out zero terms 
  # because xyz all have different
  # zero patterns

  return($a, $b, $c);

}


1;


    

