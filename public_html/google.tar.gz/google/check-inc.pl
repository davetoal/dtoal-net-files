

for my $p (@INC) {

  print "path is $p\n";

  my @l = `ls -l $p`;

  for (@l) { print "$_"; }

  print "\n";

}


