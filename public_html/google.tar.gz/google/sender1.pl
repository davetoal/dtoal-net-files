
# dave toal

use strict;

use Google::Search;

use Data::Dumper;



my $count;


my $search = Google::Search->Web( query => "ping" );

while ( my $result = $search->next ) {

  print $result->rank, " ", $result->uri, "\n";

  print $result->content, "\n";

  # print Dumper $result;

  $count++;

  exit if ($count);

}


