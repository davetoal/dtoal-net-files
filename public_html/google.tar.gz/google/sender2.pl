


my $key = "ABQIAAAAjGMhTDCja1w3NjRbgIb3rhSBf72mSum0F5ue9A5pGgBpENhVERQbyONtlSZWSKFcrtXBtMbbYTWz";
my $referrer = "http://testpage.dtoal.com";

use REST::Google::Search;

REST::Google::Search->http_referer($referrer);






my $noconnect = 1;
 while ($noconnect) {
   $res = REST::Google::Search->new(q => $query);
   # die "response status failure" if $res->responseStatus != 200;

   if ($res->responseStatus != 200) {

     print "........\n";

     print "retrying query, response was " . $res->responseStatus . "...\n";

     system("aplay $retry >/dev/null 2>&1");

     open(Q, ">> $querylog");
     print Q "$query  ";
     print Q $res->responseStatus;
     print Q "\n";
     close(Q);
     
     # sleep 15;
     sleep 10;

   } else {
     $noconnect = 0;
   }
 }


 my $data = $res->responseData;

 my $cursor = $data->cursor;
 my $pages = $cursor->pages;

 printf("current page index: %s\n", $cursor->currentPageIndex);
 printf("estimated result count: %s\n", $cursor->estimatedResultCount);
 print "\n";

 print R "current page index: "      . $cursor->currentPageIndex      . "\n";
 print R "estimated result count: "  . $cursor->estimatedResultCount  . "\n";
 print R "\n";


 my @results = $data->results;




foreach my $r (@results) {

   printf("title: %s\n", $r->title);
   printf("content: %s\n", $r->content);
   printf("url: %s\n", $r->url);
   print "\n";

   print R "title: " . $r->title . "\n";
   print R "content: " . $r->content . "\n";
   print R "url: " . $r->url . "\n";
   print R "\n";

   $save{$r->title} = $r->url;

 }

 print "\n";

 print R "\n";
 close(R);


 # sleep 5;
 # make it a bit more obvs that its runnng,
 my $tdelay;
 if ($audio < 0) { $tdelay = 3; }
            else { $tdelay = 5; }
 for (my $t = 0; $t < $tdelay; $t++) { print "\n"; sleep 1; }


}





__DATA__


>>When she happened to fetch out a long word which had had its day weeks before and its prepared meanings gone to her dump-pile, if there was a stranger there of course it knocked him groggy for a couple of minutes, then he would come to, and by that time she would be away down wind on another tack, and not expecting anything; so when he'd hail and ask her to cash in, I (the only dog on the inside of her game) could see her canvas flicker a moment--but only just a moment--then it would belly out taut and full, and she would say, as calm as a summer's day, "It's synonymous with supererogation," or some godless long reptile of a word like that, and go placidly about and skim away on the next tack, perfectly comfortable, you know, and leave that stranger looking profane and embarrassed, and the initiated slatting the floor with their tails in unison and their faces transfigured with a holy joy.<<$




